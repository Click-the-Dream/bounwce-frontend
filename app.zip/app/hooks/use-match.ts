"use client";
import { useAuth } from "../context/AuthContext";
import api from "../services/api";
import {
  useInfiniteQuery,
  useMutation,
  useQuery,
  useQueryClient,
} from "@tanstack/react-query";

const useMatch = () => {
  const { authDetails } = useAuth();
  const queryClient = useQueryClient();

  const useGetSuggestedCandidates = () => {
    return useInfiniteQuery({
      queryKey: ["matches", "suggest"],
      queryFn: async ({ pageParam = 1 }) => {
        const res = await api.get(`/matches/suggest?page=${pageParam}`);
        return res?.data; // Return the whole object to access 'has_next'
      },
      getNextPageParam: (lastPage) => {
        return lastPage.has_next ? lastPage.page + 1 : undefined;
      },
      enabled: !!authDetails?.access_token,
      initialPageParam: 1,
    });
  };

  const useGetMatchRequests = ({
    enabled = true,
  }: { enabled?: boolean } = {}) => {
    return useQuery({
      queryKey: ["matches", "requests"],
      queryFn: async () => {
        const res = await api.get("/matches/requests");
        return res?.data;
      },
      enabled: !!authDetails?.access_token && enabled,
    });
  };

  // POST: Create Match Request
  const createMatchRequest = useMutation({
    mutationFn: async (payload: {
      target_user_id: string;
      message?: string;
    }) => {
      const res = await api.post("/matches/requests", payload);
      return res.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["matches", "requests"] });
      queryClient.invalidateQueries({ queryKey: ["matches", "suggest"] });
    },
  });

  // POST: Respond to Match Request (accept/reject)
  const respondToMatchRequest = useMutation({
    mutationFn: async (payload: {
      request_id: string;
      action: "accept" | "reject";
    }) => {
      const res = await api.post(
        `/matches/requests/${payload.request_id}/respond`,
        {
          accepted: payload.action === "accept" ? true : false,
        },
      );
      return res.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["matches", "requests"] });
      queryClient.invalidateQueries({ queryKey: ["matches"] });
    },
  });

  // GET: Matches (confirmed matches)
  const useGetMatches = () => {
    return useQuery({
      queryKey: ["matches", "list"],
      queryFn: async () => {
        const res = await api.get("/matches");
        return res?.data || [];
      },
      enabled: !!authDetails?.access_token,
    });
  };
  const useGetMatchesByUserId = (user_id?: string) => {
    return useQuery({
      queryKey: ["matches", user_id],
      queryFn: async () => {
        const res = await api.get(`/matches/${user_id}`);
        return res?.data || [];
      },
      enabled: !!authDetails?.access_token && !!user_id,
    });
  };

  const useBouwnceSearch = (message: string, page_size: number = 10) => {
    return useInfiniteQuery({
      queryKey: ["matches", "search", message, page_size],

      enabled: !!message,

      initialPageParam: 1,

      queryFn: async ({ pageParam = 1 }) => {
        const res = await api.get("/search/parse", {
          params: {
            message,
            domain: "buddy",
            page: pageParam,
            page_size,
          },
        });

        return res.data;
      },

      getNextPageParam: (lastPage, allPages) => {
        const hasNext = lastPage?.data?.search_results?.has_next;

        return hasNext ? allPages.length + 1 : undefined;
      },
    });
  };

  return {
    useGetSuggestedCandidates,
    useGetMatchRequests,
    useGetMatches,
    useBouwnceSearch,
    createMatchRequest,
    respondToMatchRequest,
    useGetMatchesByUserId,
  };
};

export default useMatch;
