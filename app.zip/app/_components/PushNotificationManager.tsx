"use client";

import { useCallback, useEffect, useState } from "react";
import useNotificationServices from "@/app/hooks/use-notification";

function urlBase64ToUint8Array(base64String: string): ArrayBuffer {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const rawData = window.atob(base64);
  const buffer = new ArrayBuffer(rawData.length);
  const bytes = new Uint8Array(buffer);
  [...rawData].forEach((char, index) => {
    bytes[index] = char.charCodeAt(0);
  });

  return buffer;
}

export default function PushNotificationManager() {
  const { vapidPublicKey, subscribePush, unsubscribePush } =
    useNotificationServices();

  const { data: vapidData } = vapidPublicKey();

  const [registration, setRegistration] =
    useState<ServiceWorkerRegistration | null>(null);

  // REGISTER SERVICE WORKER
  useEffect(() => {
    if (typeof window === "undefined" || !("serviceWorker" in navigator)) {
      return;
    }

    navigator.serviceWorker
      .register("/push-sw.js")
      .then((registered) => {
        console.log("[PUSH] Service worker registered", registered);

        setRegistration(registered);
      })
      .catch((error) => {
        console.error("[PUSH] Service worker registration failed", error);
      });
  }, []);

  // GET VAPID KEY
  const getVapidKey = useCallback(() => {
    if (!vapidData?.public_key) return null;

    return vapidData.public_key ?? null;
  }, [vapidData]);

  // ENABLE PUSH
  const enablePush = useCallback(async () => {
    try {
      if (!registration) {
        console.warn("[PUSH] Service worker is not ready");
        return;
      }

      if (!("PushManager" in window)) {
        console.warn("[PUSH] Push notifications are not supported");
        return;
      }

      // Ask permission
      const permission = await Notification.requestPermission();

      if (permission !== "granted") {
        console.warn("[PUSH] Notification permission denied");
        return;
      }

      const publicKey = getVapidKey();

      if (!publicKey) {
        console.error("[PUSH] VAPID public key is missing");
        return;
      }

      // Check if browser already has subscription
      let subscription = await registration.pushManager.getSubscription();

      // Create subscription if necessary
      if (!subscription) {
        subscription = await registration.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: urlBase64ToUint8Array(publicKey),
        });
      }

      console.log("[PUSH] Browser subscription:", subscription);

      // Send subscription to backend
      await subscribePush.mutateAsync(subscription.toJSON());

      console.log("[PUSH] Subscription saved successfully");
    } catch (error) {
      console.error("[PUSH] Failed to enable push notifications", error);
    }
  }, [registration, getVapidKey, subscribePush]);

  // DISABLE PUSH
  const disablePush = useCallback(async () => {
    try {
      if (!registration) return;

      const subscription = await registration.pushManager.getSubscription();

      // Tell backend first
      await unsubscribePush.mutateAsync();

      // Then remove browser subscription
      if (subscription) {
        await subscription.unsubscribe();
      }

      console.log("[PUSH] Push notifications disabled");
    } catch (error) {
      console.error("[PUSH] Failed to disable push notifications", error);
    }
  }, [registration, unsubscribePush]);

  // AUTO-SYNC EXISTING PERMISSION
  useEffect(() => {
    if (!registration) return;

    if (
      typeof Notification === "undefined" ||
      Notification.permission !== "granted"
    ) {
      return;
    }

    enablePush();
  }, [registration, enablePush]);

  // Expose functions globally for now.
  //
  // Better long-term: put these functions in a
  // PushNotificationContext.
  useEffect(() => {
    window.dispatchEvent(
      new CustomEvent("push:ready", {
        detail: {
          enablePush,
          disablePush,
        },
      }),
    );
  }, [enablePush, disablePush]);

  return null;
}
