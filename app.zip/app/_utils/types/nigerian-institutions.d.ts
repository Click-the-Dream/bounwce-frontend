declare module "nigerian-institutions";
