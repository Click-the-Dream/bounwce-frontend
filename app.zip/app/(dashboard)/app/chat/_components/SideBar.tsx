"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Search, PlusCircle } from "lucide-react";
import ChatCard from "./ChatCard";
import { useParams } from "next/navigation";
import NewChatModal from "./NewChatModal";
import useChat from "@/app/hooks/use-chat";
import { User } from "@/app/_utils/types/buyer";
import { ChatUser } from "@/app/_utils/types/chat";

interface ChatSidebarProps {
  selectedUser?: User;
  role?: "buyer" | "vendor";
}

const ChatSidebar = ({ selectedUser, role = "buyer" }: ChatSidebarProps) => {
  const { useGetConversations } = useChat();
  const { chatId } = useParams();

  const [searchQuery, setSearchQuery] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);

  const params = useMemo(
    () => ({
      page_size: 10,
    }),
    [],
  );

  const { data, fetchNextPage, hasNextPage, isFetchingNextPage, isLoading } =
    useGetConversations(params);

  const conversations =
    data?.pages?.flatMap((page: any) => page?.items || []) || [];

  const activeConversation = useMemo(() => {
    if (!selectedUser) return null;

    const existing = conversations?.find(
      (c: any) => c.user?.id === selectedUser.id,
    );

    if (existing) return null;

    return {
      id: `temp-${selectedUser.id}`,
      user: {
        ...selectedUser,
      },
    };
  }, [selectedUser, conversations]);

  const filteredConversations = useMemo(() => {
    const baseList = [...conversations];

    if (activeConversation) {
      baseList.unshift(activeConversation);
    }

    const sortedList = baseList.sort((a: any, b: any) => {
      const aIsBouwnce =
        a.user?.username?.toLowerCase() === "bouwnce" ||
        a.user?.id === "3c729ba4-a89d-4670-ba99-faa91737a5e7";

      const bIsBouwnce =
        b.user?.username?.toLowerCase() === "bouwnce" ||
        b.user?.id === "3c729ba4-a89d-4670-ba99-faa91737a5e7";

      if (aIsBouwnce) return -1;
      if (bIsBouwnce) return 1;

      return 0;
    });

    if (!searchQuery) return sortedList;

    return sortedList.filter((conversation: any) =>
      conversation.user?.full_name
        ?.toLowerCase()
        .includes(searchQuery.toLowerCase()),
    );
  }, [conversations, searchQuery, activeConversation]);

  const scrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const container = scrollRef.current;
    if (!container) return;

    const handleScroll = () => {
      const { scrollTop, scrollHeight, clientHeight } = container;

      const isBottom = scrollTop + clientHeight >= scrollHeight - 50;

      if (isBottom && hasNextPage && !isFetchingNextPage) {
        fetchNextPage();
      }
    };

    container.addEventListener("scroll", handleScroll);

    return () => {
      container.removeEventListener("scroll", handleScroll);
    };
  }, [fetchNextPage, hasNextPage, isFetchingNextPage]);
  return (
    <div
      className={`w-80 min-w-80 h-full min-h-0 flex flex-col bg-white border-r-[0.53px] border-[#00000033] overflow-hidden
    ${chatId ? "hidden md:flex" : "flex-1 md:flex md:flex-0"}`}
    >
      {/* HEADER */}
      <div className="p-4 flex items-center justify-between h-15.5 border-b-[0.53px] border-[#00000033]">
        <h2 className="text-[16px] font-semibold">Chats</h2>

        <button
          onClick={() => setIsModalOpen(true)}
          className="cursor-pointer max-w-17.75 h-7.5 flex-1 bg-orange outline-[0.83px] outline-orange border border-[#F4F4F4] hover:bg-[#ee3d15] text-white p-2 rounded-full text-xs font-medium flex items-center justify-center transition-all"
        >
          <PlusCircle fill="#8a0202" className="size-4 mr-1.75" />
          New
        </button>
      </div>

      {/* SEARCH */}
      <div className="relative z-5 px-2 pb-[7.73px] my-2 border-b-[0.53px] border-[#00000033]">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[#9C9C9C] size-4" />

          <input
            type="text"
            placeholder="Search..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white border-[0.53px] border-[#0000004D] rounded-[10px] py-2 pl-10 pr-4 text-sm focus:outline-none focus:border-b focus:pb-3 placeholder:text-[#9C9C9C]"
          />
        </div>
      </div>

      {/* LIST */}
      <div
        ref={scrollRef}
        className="flex-1 min-h-0 overflow-y-auto overscroll-contain px-2 pb-2"
      >
        {isLoading ? (
          <div className="text-center mt-10 text-gray-400 text-sm">
            Loading chats...
          </div>
        ) : filteredConversations.length > 0 ? (
          filteredConversations.map((chat: ChatUser) => (
            <ChatCard key={chat?.user?.id} chat={chat} />
          ))
        ) : (
          <div className="text-center mt-10 text-gray-400 text-sm">
            No chats found
          </div>
        )}

        {/* LOADING MORE INDICATOR */}
        {isFetchingNextPage && (
          <div className="text-center text-xs text-gray-400 py-2">
            Loading more...
          </div>
        )}
      </div>

      {/* MODAL */}
      <NewChatModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      />
    </div>
  );
};

export default ChatSidebar;
