"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/app/context/AuthContext";

export const ONBOARDING_VERSION = 4;

export type OnboardingPhase = "idle" | "welcome" | "profile-photo" | "tour" | "done";

export type OnboardingStep = {
  id: string;
  selector: string;
  path: string;
  location: "sidebar" | "header";
  title: string;
  description: string;
  mobileLabel: string;
  side?: "top" | "right" | "bottom" | "left";
};

export const ONBOARDING_STEPS: OnboardingStep[] = [
  {
    id: "home",
    selector: '[data-tour="home"]',
    path: "/app",
    location: "sidebar",
    mobileLabel: "Home",
    side: "right",
    title: "Your Bouwnce home",
    description: "This is your starting point. Come back here to catch up with what is happening on Bouwnce.",
  },
  {
    id: "explore",
    selector: '[data-tour="explore"]',
    path: "/app/explore",
    location: "sidebar",
    mobileLabel: "Explore",
    side: "right",
    title: "Discover people",
    description: "Explore is where you find people and new connections that match your interests.",
  },
  {
    id: "requests",
    selector: '[data-tour="requests"]',
    path: "/app/requests",
    location: "sidebar",
    mobileLabel: "Requests",
    side: "right",
    title: "Manage connection requests",
    description: "When someone wants to connect with you, their request appears here for you to review.",
  },
  {
    id: "messages",
    selector: '[data-tour="messages"]',
    path: "/app",
    location: "header",
    mobileLabel: "Messages",
    side: "bottom",
    title: "Keep the conversation going",
    description: "After you connect with someone, you can continue the conversation from Messages.",
  },
  {
    id: "notifications",
    selector: '[data-tour="notifications"]',
    path: "/app",
    location: "header",
    mobileLabel: "Notifications",
    side: "bottom",
    title: "Stay in the loop",
    description: "Notifications keep you updated when something important happens on Bouwnce.",
  },
  {
    id: "events",
    selector: '[data-tour="events"]',
    path: "/app/events",
    location: "sidebar",
    mobileLabel: "Events",
    side: "right",
    title: "Find things to do",
    description: "Discover events and experiences where you can meet people through shared activities.",
  },
  {
    id: "profile",
    selector: '[data-tour="profile"]',
    path: "/app/profile",
    location: "sidebar",
    mobileLabel: "Profile",
    side: "right",
    title: "Make your profile yours",
    description: "Your profile is how people recognize you. Keep your information, interests and photo up to date.",
  },
];

type ContextValue = {
  phase: OnboardingPhase;
  steps: OnboardingStep[];
  stepIndex: number;
  currentStep: OnboardingStep | null;
  profileNeedsPhoto: boolean;
  nextStep: () => void;
  previousStep: () => void;
  setStepIndex: (index: number) => void;
  startTour: () => void;
  startProfileSetup: () => void;
  skip: () => void;
  finish: () => void;
};

const OnboardingContext = createContext<ContextValue | null>(null);

function keyFor(userId: string) {
  return `bouwnce:onboarding:${userId}:v${ONBOARDING_VERSION}`;
}

export function OnboardingProvider({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const { authDetails, isLoading } = useAuth();
  const user = authDetails?.user;
  const userId = user?.id;
  const profileNeedsPhoto = !user?.profile_pic;

  const [phase, setPhase] = useState<OnboardingPhase>("idle");
  const [stepIndex, setStepIndex] = useState(0);

  useEffect(() => {
    if (isLoading || !userId || typeof window === "undefined") return;
    const completed = localStorage.getItem(keyFor(userId)) === "completed";
    setPhase(completed ? "done" : "welcome");
  }, [isLoading, userId]);

  useEffect(() => {
    const onPhotoUpdated = () => {
      if (phase !== "profile-photo") return;
      setStepIndex(0);
      setPhase("tour");
      router.push("/app");
    };
    window.addEventListener("bouwnce:profile-photo-updated", onPhotoUpdated);
    return () => window.removeEventListener("bouwnce:profile-photo-updated", onPhotoUpdated);
  }, [phase, router]);

  const complete = useCallback(() => {
    if (userId && typeof window !== "undefined") localStorage.setItem(keyFor(userId), "completed");
    window.dispatchEvent(new Event("bouwnce:onboarding:close-menu"));
    setPhase("done");
  }, [userId]);

  const startProfileSetup = useCallback(() => {
    setPhase("profile-photo");
    router.push("/app/profile");
  }, [router]);

  const startTour = useCallback(() => {
    if (profileNeedsPhoto) {
      startProfileSetup();
      return;
    }
    setStepIndex(0);
    setPhase("tour");
    router.push("/app");
  }, [profileNeedsPhoto, router, startProfileSetup]);

  const skip = useCallback(() => {
    complete();
  }, [complete]);

  const finish = useCallback(() => complete(), [complete]);

  const nextStep = useCallback(() => {
    setStepIndex((index) => Math.min(index + 1, ONBOARDING_STEPS.length - 1));
  }, []);

  const previousStep = useCallback(() => {
    setStepIndex((index) => Math.max(index - 1, 0));
  }, []);

  const value = useMemo<ContextValue>(() => ({
    phase,
    steps: ONBOARDING_STEPS,
    stepIndex,
    currentStep: ONBOARDING_STEPS[stepIndex] ?? null,
    profileNeedsPhoto,
    nextStep,
    previousStep,
    setStepIndex,
    startTour,
    startProfileSetup,
    skip,
    finish,
  }), [phase, stepIndex, profileNeedsPhoto, nextStep, previousStep, startTour, startProfileSetup, skip, finish]);

  return <OnboardingContext.Provider value={value}>{children}</OnboardingContext.Provider>;
}

export function useOnboarding() {
  const context = useContext(OnboardingContext);
  if (!context) throw new Error("useOnboarding must be used inside OnboardingProvider");
  return context;
}
