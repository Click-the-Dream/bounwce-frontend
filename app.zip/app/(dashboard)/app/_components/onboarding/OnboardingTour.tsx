"use client";

import { useCallback, useEffect, useRef } from "react";
import { driver, type Driver } from "driver.js";
import "driver.js/dist/driver.css";
import "./onboarding.css";
import { usePathname, useRouter } from "next/navigation";
import { ArrowRight, Camera, CheckCircle2 } from "lucide-react";
import { Portal } from "@/app/protocols/Portal";
import { useOnboarding } from "./OnboardingProvider";

const sleep = (ms: number) => new Promise((resolve) => window.setTimeout(resolve, ms));

function isMobile() {
  return typeof window !== "undefined" && window.matchMedia("(max-width: 1023px)").matches;
}

function waitFor(selector: string, timeout = 1800): Promise<Element | null> {
  return new Promise((resolve) => {
    const start = Date.now();
    const tick = () => {
      const el = document.querySelector(selector);
      if (el) return resolve(el);
      if (Date.now() - start >= timeout) return resolve(null);
      window.setTimeout(tick, 60);
    };
    tick();
  });
}

export default function OnboardingTour() {
  const router = useRouter();
  const pathname = usePathname();
  const driverRef = useRef<Driver | null>(null);
  const {
    phase,
    steps,
    stepIndex,
    currentStep,
    profileNeedsPhoto,
    startTour,
    startProfileSetup,
    nextStep,
    previousStep,
    setStepIndex,
    skip,
    finish,
  } = useOnboarding();

  const openMenu = useCallback(() => {
    window.dispatchEvent(new Event("bouwnce:onboarding:open-menu"));
  }, []);

  const closeMenu = useCallback(() => {
    window.dispatchEvent(new Event("bouwnce:onboarding:close-menu"));
  }, []);

  const prepareStep = useCallback(async (index: number) => {
    const step = steps[index];
    if (!step) return;

    if (step.path && pathname !== step.path) {
      router.push(step.path);
      await sleep(180);
    }

    if (isMobile()) {
      if (step.location === "sidebar") {
        openMenu();
        await sleep(180);
      } else {
        closeMenu();
        await sleep(100);
      }
    }

    await waitFor(step.selector);
  }, [closeMenu, openMenu, pathname, router, steps]);

  const destroy = useCallback(() => {
    driverRef.current?.destroy();
    driverRef.current = null;
  }, []);

  const buildTour = useCallback(() => {
    destroy();

    const tour = driver({
      animate: true,
      allowKeyboardControl: true,
      overlayOpacity: 0.66,
      stagePadding: isMobile() ? 8 : 10,
      stageRadius: 12,
      popoverOffset: isMobile() ? 12 : 14,
      popoverClass: "bouwnce-driver-popover",
      showProgress: true,
      progressText: "{{current}} of {{total}}",
      overlayClickBehavior: "close",
      disableActiveInteraction: false,
      steps: steps.map((step) => ({
        element: step.selector,
        popover: {
          title: step.title,
          description: step.description,
          side: isMobile() ? "bottom" : step.side,
          align: "center",
          showButtons: ["previous", "next", "close"],
          nextBtnText: step.id === steps[steps.length - 1].id ? "Finish" : "Next",
          prevBtnText: "Back",
          doneBtnText: "Finish",
        },
        disableActiveInteraction: true,
        skipMissingElement: false,
        waitForElement: 2000,
      })),
      onHighlightStarted: async (_element, step) => {
        const index = steps.findIndex((item) => item.id === step.id);
        if (index < 0) return;
        setStepIndex(index);
        await prepareStep(index);
      },
      onNextClick: async () => {
        const current = driverRef.current?.getActiveIndex() ?? stepIndex;
        const next = current + 1;
        if (next >= steps.length) {
          finish();
          destroy();
          return;
        }
        await prepareStep(next);
        setStepIndex(next);
        nextStep();
        driverRef.current?.moveTo(next);
      },
      onPrevClick: async () => {
        const current = driverRef.current?.getActiveIndex() ?? stepIndex;
        const previous = Math.max(current - 1, 0);
        await prepareStep(previous);
        setStepIndex(previous);
        previousStep();
        driverRef.current?.moveTo(previous);
      },
      onCloseClick: () => {
        destroy();
        closeMenu();
        skip();
      },
      onDestroyed: () => {
        closeMenu();
      },
    });

    driverRef.current = tour;
    return tour;
  }, [closeMenu, destroy, finish, nextStep, prepareStep, previousStep, setStepIndex, skip, stepIndex, steps]);

  useEffect(() => {
    if (phase !== "tour") {
      destroy();
      return;
    }
    let cancelled = false;
    const start = async () => {
      await prepareStep(0);
      if (cancelled) return;
      const tour = buildTour();
      tour.drive(0);
    };
    start();
    return () => {
      cancelled = true;
      destroy();
    };
  }, [phase]);

  if (phase === "welcome") {
    return (
      <Portal>
        <div className="fixed inset-0 z-[2147483000] flex items-center justify-center bg-[#17100D]/55 px-4 backdrop-blur-[3px]">
          <div className="bouwnce-welcome-card w-full max-w-[480px] overflow-hidden rounded-[30px] bg-[#FFFDFB] shadow-[0_28px_90px_rgba(20,10,8,.35)]">
            <div className="relative px-6 pb-6 pt-7 sm:px-8 sm:pt-9">
              <div className="mb-6 flex items-center gap-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#FFF0EA] text-[#FF4B2B]">
                  <ArrowRight size={21} />
                </div>
                <div>
                  <p className="text-[10px] font-black uppercase tracking-[.18em] text-[#FF4B2B]">Welcome to Bouwnce</p>
                  <p className="mt-1 text-[12px] font-medium text-[#8A8582]">A quick tour, then you are ready to go.</p>
                </div>
              </div>

              <h1 className="max-w-[390px] text-[31px] font-semibold leading-[1.03] tracking-[-.045em] text-[#171413] sm:text-[38px]">
                Let&apos;s get you comfortable on Bouwnce.
              </h1>
              <p className="mt-4 max-w-[400px] text-[14px] leading-6 text-[#6E6865]">
                We&apos;ll show you where the important things live, so your first experience feels simple instead of overwhelming.
              </p>

              <div className="mt-6 grid gap-2 sm:grid-cols-3">
                {[
                  ["Discover", "Find people"],
                  ["Connect", "Start conversations"],
                  ["Experience", "Find events"],
                ].map(([a, b]) => (
                  <div key={a} className="rounded-2xl border border-black/[.06] bg-white px-3.5 py-3">
                    <div className="text-[11px] font-extrabold text-[#171413]">{a}</div>
                    <div className="mt-0.5 text-[10px] font-medium text-[#96908D]">{b}</div>
                  </div>
                ))}
              </div>

              {profileNeedsPhoto && (
                <div className="mt-5 flex items-start gap-3 rounded-2xl border border-[#FF4B2B]/10 bg-[#FFF4EF] px-4 py-3.5">
                  <Camera size={17} className="mt-0.5 shrink-0 text-[#FF4B2B]" />
                  <div>
                    <p className="text-[12px] font-extrabold text-[#743B2D]">One important setup first</p>
                    <p className="mt-1 text-[11px] leading-4.5 text-[#925C4E]">We&apos;ll ask you to add a profile photo so people can recognize you.</p>
                  </div>
                </div>
              )}

              <div className="mt-7 flex flex-col-reverse gap-2.5 sm:flex-row sm:items-center sm:justify-between">
                <button onClick={skip} className="h-12 rounded-2xl px-4 text-[13px] font-bold text-[#77706D] hover:bg-black/[.03]">Skip tour</button>
                <button onClick={startTour} className="inline-flex h-12 items-center justify-center gap-2 rounded-2xl bg-[#FF4B2B] px-6 text-[13px] font-extrabold text-white shadow-[0_12px_28px_rgba(255,75,43,.24)] transition-transform hover:-translate-y-0.5 active:translate-y-0">
                  Show me around <ArrowRight size={16} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </Portal>
    );
  }

  if (phase === "profile-photo") {
    const onProfile = pathname === "/app/profile";
    return (
      <Portal>
        <div className="fixed inset-0 z-[2147483000] bg-[#17100D]/45 backdrop-blur-[2px]">
          <div className="absolute inset-x-0 bottom-0 p-3 pb-[max(12px,env(safe-area-inset-bottom))] sm:inset-auto sm:left-1/2 sm:top-1/2 sm:w-[440px] sm:-translate-x-1/2 sm:-translate-y-1/2 sm:p-0">
            <div className="rounded-[28px] border border-black/[.06] bg-[#FFFDFB] p-5 shadow-[0_25px_80px_rgba(20,10,8,.32)] sm:p-6">
              <div className="flex items-center justify-between">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#FFF0EA] text-[#FF4B2B]"><Camera size={18} /></div>
                <div className="rounded-full bg-[#F4F1EE] px-3 py-1 text-[10px] font-extrabold uppercase tracking-[.12em] text-[#807A76]">Profile setup</div>
              </div>
              <h2 className="mt-5 text-[24px] font-semibold tracking-[-.035em] text-[#171413]">Put a face to your profile</h2>
              <p className="mt-2 text-[13px] leading-5 text-[#6E6865]">A profile photo makes it easier for people to recognize you and is one of the most important parts of your Bouwnce profile.</p>
              <div className="mt-4 rounded-2xl bg-[#FFF4EF] px-4 py-3 text-[11px] font-semibold leading-4.5 text-[#8A5142]">
                {onProfile ? "Tap the small camera button on your profile photo. We will continue automatically after you save it." : "Open your profile and we will point you to the exact camera button."}
              </div>
              <div className="mt-5 flex gap-2.5">
                <button onClick={skip} className="h-11 rounded-2xl px-4 text-[12px] font-bold text-[#77706D]">Later</button>
                <button onClick={startProfileSetup} className="flex h-11 flex-1 items-center justify-center gap-2 rounded-2xl bg-[#FF4B2B] text-[12px] font-extrabold text-white">
                  {onProfile ? "Got it" : "Open my profile"} <ArrowRight size={14} />
                </button>
              </div>
              {onProfile && <div className="mt-3 text-center text-[10px] font-semibold text-[#A29A96]">Look for the camera icon on your profile photo</div>}
            </div>
          </div>
        </div>
      </Portal>
    );
  }

  return null;
}
